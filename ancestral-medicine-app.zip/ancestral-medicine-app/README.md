# 🌿 Ancestral Medicine Plants App

A Progressive Web App (PWA) for natural home remedies using ancestral medicinal plants.

## ✨ Features

- **12 Medicinal Plants** — Ginger, Turmeric, Garlic, Aloe Vera, Peppermint, Chamomile, Plantain, Elderberry, Cayenne, Lavender, Dandelion, Eucalyptus
- **50+ Remedy Recipes** — Step-by-step preparation instructions
- **Plant Scanner** — Use your camera to identify plants (demo mode / integrate TensorFlow.js model for full AI)
- **Emergency Guide** — First aid using available plants when medical care is unavailable
- **Fully Offline** — Works without internet via Service Worker caching
- **Install on Phone** — Add to homescreen for native app experience
- **Browse by Ailment** — Cough, Cold, Liver, Heart, Wounds, Anxiety, Sleep, and more

## 🚀 How to Run

### Option 1: Open directly in browser
Just open `index.html` in any modern browser. 

> Note: Camera and Service Worker features require a server (HTTPS or localhost).

### Option 2: Local server (recommended)
```bash
# Python 3
python3 -m http.server 8000

# Then open: http://localhost:8000
```

### Option 3: Deploy online (for mobile install)
Upload all files to any web host:
- GitHub Pages (free)
- Netlify (free)
- Vercel (free)
- Any Apache/Nginx server

After deploying to HTTPS, users can tap "Add to Home Screen" to install as a native-like app.

## 📱 Installing on Phone

1. Open the app URL in Chrome (Android) or Safari (iOS)
2. For Android: Tap the "Install" banner or browser menu → "Add to Home Screen"
3. For iOS (Safari): Tap Share button → "Add to Home Screen"
4. The app will work fully offline once installed!

## 📁 File Structure

```
ancestral-medicine-app/
├── index.html          — Main app (all pages)
├── manifest.json       — PWA manifest for installation
├── sw.js               — Service Worker for offline support
├── data/
│   └── plants.js       — Complete plant & remedy database
├── js/
│   └── app.js          — All app logic
└── icons/
    ├── icon-192.png    — App icon
    └── icon-512.png    — App icon (large)
```

## 🌿 Adding More Plants

Edit `data/plants.js` and add new entries to the `PLANTS_DB` array following the same structure. Add ailment IDs to `AILMENTS_INDEX` as well.

## 🤖 Upgrading the Plant Scanner

For real AI plant identification (fully offline):
1. Download a TensorFlow.js plant identification model (e.g., PlantNet)
2. Store the model files in a `/model` folder
3. Replace the `simulatePlantIdentification()` function in `app.js` with TF.js model inference

## ⚠️ Medical Disclaimer

This app provides traditional and ancestral herbal knowledge for educational purposes. It is NOT a replacement for professional medical advice. Always consult a qualified healthcare provider for serious medical conditions. In emergencies, always call emergency services when available.

## 📜 License

Free to use, modify, and distribute for educational and humanitarian purposes.
