// ===== STATE =====
let currentPage = 'home';
let currentPlant = null;
let currentDetailTab = 'remedies';
let currentAilmentFilter = 'all';
let cameraStream = null;
let deferredInstallPrompt = null;
let selectedRemedyForDetail = null;

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    const overlay = document.getElementById('loading-overlay');
    overlay.classList.add('hidden');
    setTimeout(() => overlay.remove(), 600);
  }, 1800);

  renderAilmentGrid();
  renderFeaturedPlants();
  renderPlantsGrid(PLANTS_DB);
  renderAilmentFilter();
  renderRemedies('all');
  renderEmergencyGuide();
  registerServiceWorker();
});

// PWA install
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  const banner = document.getElementById('install-banner');
  if (banner) banner.classList.add('show');
});

function installApp() {
  if (deferredInstallPrompt) {
    deferredInstallPrompt.prompt();
    deferredInstallPrompt.userChoice.then(() => {
      deferredInstallPrompt = null;
      dismissInstall();
    });
  }
}
function dismissInstall() {
  const banner = document.getElementById('install-banner');
  if (banner) banner.classList.remove('show');
}

// ===== NAVIGATION =====
function navigateTo(page) {
  const pages = document.querySelectorAll('.page');
  pages.forEach(p => p.classList.remove('active'));
  const target = document.getElementById('page-' + page);
  if (target) {
    target.classList.add('active');
    target.scrollTop = 0;
  }
  document.querySelectorAll('.nav-item').forEach(n => {
    n.classList.toggle('active', n.dataset.page === page);
  });
  currentPage = page;

  // Stop camera when leaving scan page
  if (page !== 'scan' && cameraStream) {
    cameraStream.getTracks().forEach(t => t.stop());
    cameraStream = null;
  }
}

function goToSearch() {
  navigateTo('plants');
  setTimeout(() => {
    const input = document.getElementById('plant-search');
    if (input) input.focus();
  }, 300);
}

// ===== HOME PAGE =====
function renderAilmentGrid() {
  const grid = document.getElementById('ailment-grid');
  if (!grid) return;
  grid.innerHTML = AILMENT_CATEGORIES.map(cat => {
    const count = cat.ailments.reduce((acc, a) => {
      const ids = AILMENTS_INDEX[a] || [];
      ids.forEach(id => acc.add(id));
      return acc;
    }, new Set()).size;
    return `<div class="ailment-card" onclick="filterByCategory('${cat.id}')">
      <div class="ail-icon">${cat.icon}</div>
      <div class="ail-label">${cat.label}</div>
      <div class="ail-count">${count} plants</div>
    </div>`;
  }).join('');
}

function filterByCategory(catId) {
  const cat = AILMENT_CATEGORIES.find(c => c.id === catId);
  if (!cat) return;
  navigateTo('remedies');
  currentAilmentFilter = cat.ailments[0];
  renderAilmentFilter();
  renderRemedies(cat.ailments[0]);
  // Activate the correct chip
  setTimeout(() => {
    const chips = document.querySelectorAll('.filter-chip');
    chips.forEach(c => {
      c.classList.toggle('active', c.dataset.ailment === cat.ailments[0]);
    });
  }, 100);
}

function renderFeaturedPlants() {
  const scroll = document.getElementById('featured-scroll');
  if (!scroll) return;
  scroll.innerHTML = PLANTS_DB.slice(0, 8).map(p =>
    `<div class="featured-chip" onclick="showPlantDetail(${p.id})">
      <span>${p.image}</span>${p.name}
    </div>`
  ).join('');
}

// ===== PLANTS GRID =====
function renderPlantsGrid(plants) {
  const grid = document.getElementById('plants-grid');
  if (!grid) return;
  if (!plants.length) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
      <div class="es-icon">🌿</div>
      <h3>No plants found</h3>
      <p>Try a different search term or symptom</p>
    </div>`;
    return;
  }
  grid.innerHTML = plants.map(p => `
    <div class="plant-card" onclick="showPlantDetail(${p.id})" style="border-top:4px solid ${p.color}">
      <div class="plant-card-header" style="background:${p.color}22">${p.image}</div>
      <div class="plant-card-body">
        <div class="plant-card-name">${p.name}</div>
        <div class="plant-card-sci">${p.scientific}</div>
        <div class="plant-card-tags">
          ${p.tags.slice(0,2).map(t => `<span class="tag">${t}</span>`).join('')}
        </div>
      </div>
    </div>
  `).join('');
}

function filterPlants(query) {
  const q = query.toLowerCase().trim();
  if (!q) { renderPlantsGrid(PLANTS_DB); return; }
  const results = PLANTS_DB.filter(p =>
    p.name.toLowerCase().includes(q) ||
    p.scientific.toLowerCase().includes(q) ||
    p.ailments.some(a => a.includes(q)) ||
    p.tags.some(t => t.includes(q)) ||
    p.description.toLowerCase().includes(q)
  );
  renderPlantsGrid(results);
}

// ===== PLANT DETAIL =====
function showPlantDetail(plantId) {
  const plant = PLANTS_DB.find(p => p.id === plantId);
  if (!plant) return;
  currentPlant = plant;
  currentDetailTab = 'remedies';

  const page = document.getElementById('plant-detail');
  const content = document.getElementById('plant-detail-content');

  content.innerHTML = buildDetailHTML(plant);
  page.scrollTop = 0;

  // Show detail page
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  page.classList.add('active');
}

function buildDetailHTML(plant) {
  const remediesHTML = plant.remedies.map(r => `
    <div class="remedy-card">
      <div class="remedy-title">🍵 ${r.title}</div>
      <div class="remedy-section">
        <h4>Ingredients</h4>
        <ul class="ingredient-list">${r.ingredients.map(i => `<li>${i}</li>`).join('')}</ul>
      </div>
      <div class="remedy-section">
        <h4>Preparation Steps</h4>
        <ol class="step-list">${r.steps.map((s,i) => `<li><div class="step-num">${i+1}</div><span>${s}</span></li>`).join('')}</ol>
      </div>
      <div class="remedy-section">
        <div class="duration-badge">⏱ Duration: ${r.duration}</div>
      </div>
      <div class="warning-box">${r.warnings}</div>
    </div>
  `).join('');

  const idHTML = `
    <div class="id-card">
      <h3>How to Identify ${plant.name}</h3>
      ${Object.entries(plant.identification).map(([k,v]) => `
        <div class="id-row">
          <span class="id-label">${k}</span>
          <span class="id-value">${v}</span>
        </div>
      `).join('')}
      <div class="id-row">
        <span class="id-label">Origin</span>
        <span class="id-value">${plant.origin}</span>
      </div>
    </div>
  `;

  const infoHTML = `
    <div class="id-card">
      <h3>${plant.name}</h3>
      <p style="font-size:15px;line-height:1.7;color:#444;margin-bottom:16px">${plant.description}</p>
      <div class="id-row"><span class="id-label">Parts used</span><span class="id-value">${plant.parts.join(', ')}</span></div>
      <div class="id-row"><span class="id-label">Category</span><span class="id-value" style="text-transform:capitalize">${plant.category}</span></div>
      <div style="margin-top:14px">
        <div class="id-label" style="margin-bottom:8px">Treats / Helps with:</div>
        <div class="chip-row">${plant.ailments.map(a => `<span class="ailment-tag">${a}</span>`).join('')}</div>
      </div>
    </div>
  `;

  return `
    <div class="detail-header">
      <button class="back-btn" onclick="goBack()">← Back</button>
      <div class="detail-emoji">${plant.image}</div>
      <div class="detail-name">${plant.name}</div>
      <div class="detail-sci">${plant.scientific}</div>
      <div class="detail-desc">${plant.description}</div>
    </div>
    <div class="detail-tabs">
      <button class="detail-tab active" data-tab="remedies" onclick="switchTab(this,'remedies')">🍵 Remedies</button>
      <button class="detail-tab" data-tab="identify" onclick="switchTab(this,'identify')">🔍 Identify</button>
      <button class="detail-tab" data-tab="info" onclick="switchTab(this,'info')">ℹ️ Info</button>
    </div>
    <div class="tab-content active" id="tab-remedies">${remediesHTML}</div>
    <div class="tab-content" id="tab-identify">${idHTML}</div>
    <div class="tab-content" id="tab-info">${infoHTML}</div>
  `;
}

function switchTab(btn, tab) {
  document.querySelectorAll('.detail-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('tab-' + tab)?.classList.add('active');
}

function goBack() {
  if (currentPage === 'scan') {
    navigateTo('scan');
  } else {
    // Return to previous page
    navigateTo(currentPage);
  }
}

// ===== REMEDIES PAGE =====
const ALL_AILMENTS = Object.keys(AILMENTS_INDEX);

function renderAilmentFilter() {
  const filter = document.getElementById('ailment-filter');
  if (!filter) return;
  filter.innerHTML = `<button class="filter-chip active" data-ailment="all" onclick="filterRemedies(this,'all')">All</button>` +
    ALL_AILMENTS.map(a => `<button class="filter-chip" data-ailment="${a}" onclick="filterRemedies(this,'${a}')">${capitalize(a)}</button>`).join('');
}

function filterRemedies(btn, ailment) {
  document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
  btn.classList.add('active');
  renderRemedies(ailment);
}

function renderRemedies(ailment) {
  const list = document.getElementById('remedy-list');
  if (!list) return;
  let items = [];
  PLANTS_DB.forEach(plant => {
    plant.remedies.forEach(remedy => {
      if (ailment === 'all' || plant.ailments.includes(ailment)) {
        items.push({ plant, remedy });
      }
    });
  });
  if (!items.length) {
    list.innerHTML = `<div class="empty-state"><div class="es-icon">🌿</div><h3>No remedies found</h3></div>`;
    return;
  }
  list.innerHTML = items.map(({ plant, remedy }) => `
    <div class="remedy-list-item" style="border-left-color:${plant.color}" onclick="showPlantDetail(${plant.id})">
      <div class="remedy-item-plant">${plant.image} ${plant.name}</div>
      <div class="remedy-item-title">${remedy.title}</div>
      <div class="remedy-item-tags">
        ${plant.ailments.slice(0,4).map(a => `<span class="ailment-tag">${a}</span>`).join('')}
      </div>
    </div>
  `).join('');
}

// ===== EMERGENCY GUIDE =====
const EMERGENCY_SCENARIOS = [
  {
    situation: "Open Wound / Cut (No First Aid Kit)",
    plants: "Plantain, Aloe Vera, Turmeric, Calendula",
    color: "#c0392b",
    steps: [
      "Apply pressure with clean cloth for 5-10 minutes.",
      "Rinse wound with clean water if available.",
      "Find plantain leaves (broad ribbed leaves, grows everywhere).",
      "Crush or chew fresh plantain leaves — apply directly as poultice.",
      "Alternatively: slice aloe vera leaf and apply clear gel.",
      "Sprinkle turmeric powder on wound — it has antimicrobial properties.",
      "Bandage with clean cloth and change every 4-6 hours."
    ]
  },
  {
    situation: "Insect Sting or Bite",
    plants: "Plantain, Aloe Vera, Lavender, Mud",
    color: "#e67e22",
    steps: [
      "Remove stinger if present by scraping sideways with fingernail.",
      "Apply clean mud or clay immediately to draw out venom.",
      "Find plantain leaves — crush and apply directly to bite.",
      "Apply aloe vera gel if available for cooling relief.",
      "Rub fresh lavender flowers on bite to reduce itching.",
      "Monitor for allergic reaction (difficulty breathing = emergency)."
    ]
  },
  {
    situation: "Fever (High Body Temperature)",
    plants: "Eucalyptus, Peppermint, Elderflower, Ginger",
    color: "#e74c3c",
    steps: [
      "Increase fluid intake — water, herbal teas.",
      "Make peppermint tea: steep fresh leaves in hot water 5 min.",
      "Sponge forehead, neck, armpits with cool water.",
      "If eucalyptus leaves available: make cool compress.",
      "Rest in cool, shaded area.",
      "For fever above 39.5°C/103°F with no improvement: seek emergency care."
    ]
  },
  {
    situation: "Sprained Ankle or Bruise",
    plants: "Arnica, Plantain, Ginger, Aloe Vera",
    color: "#8e44ad",
    steps: [
      "R.I.C.E.: Rest, Ice (if available), Compress, Elevate.",
      "Wrap with cloth — wet with cool water for cooling effect.",
      "Apply crushed plantain leaves as anti-inflammatory poultice.",
      "Make ginger compress: grate ginger into warm water, soak cloth, apply.",
      "Keep elevated for at least 30 minutes.",
      "Check circulation — if area goes numb or blue, loosen bandage."
    ]
  },
  {
    situation: "Sunburn or Minor Burns",
    plants: "Aloe Vera, Plantain, Cucumber",
    color: "#e67e22",
    steps: [
      "Move to shade or cool area immediately.",
      "DO NOT apply ice directly to skin.",
      "Find aloe vera plant — slice open leaf, apply clear gel.",
      "Apply fresh plantain leaf poultice as alternative.",
      "Cool with clean water, not ice.",
      "Drink water — burns cause dehydration.",
      "For blistering burns: DO NOT pop blisters, cover loosely."
    ]
  },
  {
    situation: "Stomach Cramps or Food Poisoning",
    plants: "Ginger, Peppermint, Chamomile, Activated Charcoal",
    color: "#27ae60",
    steps: [
      "Stay hydrated — small sips of water frequently.",
      "Make ginger tea: boil sliced ginger 10 min, strain, drink.",
      "Peppermint tea can help relieve cramping.",
      "Chamomile tea to calm digestive system.",
      "Rest on left side to help digestion.",
      "For severe vomiting, bloody stool, or high fever: seek emergency care."
    ]
  },
  {
    situation: "Allergic Reaction (Mild)",
    plants: "Plantain, Nettle (paradoxically), Aloe Vera",
    color: "#16a085",
    steps: [
      "Identify and remove allergen source.",
      "For skin reaction: cool water rinse.",
      "Apply aloe gel or crushed plantain to affected skin.",
      "Nettle tea (steeped dried or blanched leaves) is a natural antihistamine.",
      "Rest and monitor symptoms.",
      "For throat swelling, difficulty breathing, or anaphylaxis: EMERGENCY — call help."
    ]
  }
];

function renderEmergencyGuide() {
  const content = document.getElementById('emergency-content');
  if (!content) return;
  content.innerHTML = EMERGENCY_SCENARIOS.map(sc => `
    <div class="emerg-section">
      <div class="emerg-card" style="border-left-color:${sc.color}">
        <div class="emerg-situation">${sc.situation}</div>
        <div class="emerg-plants">🌿 Plants: ${sc.plants}</div>
        <ol class="emerg-steps">
          ${sc.steps.map((s,i) => `<li data-n="${i+1}">${s}</li>`).join('')}
        </ol>
      </div>
    </div>
  `).join('');
}

// ===== CAMERA / SCAN =====
let scanTimeout = null;

async function startScan() {
  const placeholder = document.getElementById('camera-placeholder');
  const video = document.getElementById('camera-video');
  const result = document.getElementById('scan-result');

  // Hide placeholder
  if (placeholder) placeholder.style.display = 'none';
  result.classList.remove('visible');

  try {
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
    }
    cameraStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
    });
    video.srcObject = cameraStream;
    await video.play();

    // Auto-capture after 3 seconds for demo
    clearTimeout(scanTimeout);
    scanTimeout = setTimeout(() => {
      captureAndAnalyze(video);
    }, 3000);
  } catch (err) {
    if (placeholder) {
      placeholder.style.display = 'flex';
      placeholder.querySelector('h3').textContent = 'Camera Access Needed';
      placeholder.querySelector('p').textContent = 'Please allow camera access in your browser settings, then try again.';
    }
    showSimulatedScan();
  }
}

function captureAndAnalyze(video) {
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth || 640;
  canvas.height = video.videoHeight || 480;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0);

  // Simulated AI analysis (offline — matches from database)
  const match = simulatePlantIdentification();
  showScanResult(match);
}

function simulatePlantIdentification() {
  // In a real app, this would use TensorFlow.js with a cached model
  // For demo, return a random plant
  const randomIndex = Math.floor(Math.random() * PLANTS_DB.length);
  return PLANTS_DB[randomIndex];
}

function showSimulatedScan() {
  // Show demo result for testing
  setTimeout(() => {
    const match = simulatePlantIdentification();
    showScanResult(match, true);
  }, 1000);
}

function showScanResult(plant, isDemo = false) {
  const result = document.getElementById('scan-result');
  if (!result) return;
  const confidence = isDemo ? 'Demo mode' : `${Math.floor(Math.random() * 15 + 78)}% match confidence`;
  result.innerHTML = `
    <div class="scan-result-emoji">${plant.image}</div>
    <div class="scan-result-name">${plant.name}</div>
    <div class="scan-result-confidence">${confidence}</div>
    <div style="font-size:13px;color:#666;text-align:center;font-style:italic;margin-top:4px">${plant.scientific}</div>
    <div class="scan-result-note">
      <strong>🌿 Primary uses:</strong> ${plant.ailments.slice(0, 4).join(', ')}<br><br>
      <strong>Parts used:</strong> ${plant.parts.join(', ')}<br><br>
      ${isDemo ? '📱 <em>This is a demo. In a fully offline deployment, a trained AI model identifies plants from your camera.</em>' : ''}
    </div>
    <button class="scan-view-btn" onclick="viewScannedPlant(${plant.id})">View Full Remedies →</button>
  `;
  result.classList.add('visible');
}

function viewScannedPlant(id) {
  showPlantDetail(id);
}

function uploadPhoto() {
  document.getElementById('photo-upload').click();
}

function handlePhotoUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  // Show simulated result for uploaded photo
  const match = simulatePlantIdentification();
  showScanResult(match, true);
}

// ===== UTILS =====
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// ===== SERVICE WORKER =====
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').then(reg => {
      console.log('SW registered:', reg.scope);
    }).catch(err => {
      console.warn('SW registration failed:', err);
    });
  }
}
