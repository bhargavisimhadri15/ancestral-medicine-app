const PLANTS_DB = [
  {
    id: 1,
    name: "Ginger",
    scientific: "Zingiber officinale",
    category: "root",
    image: "🫚",
    color: "#d4a853",
    description: "A warm, spicy root used for centuries across Asia, Africa, and the Americas as a powerful healing plant.",
    parts: ["Root", "Leaves", "Stem"],
    ailments: ["cough", "cold", "nausea", "stomach", "inflammation", "fever"],
    remedies: [
      {
        title: "Ginger Tea for Cold & Cough",
        ingredients: ["1 inch fresh ginger root", "2 cups water", "1 tsp honey", "Juice of half lemon"],
        steps: ["Peel and slice ginger thinly.", "Boil water and add ginger slices.", "Simmer for 10 minutes on low heat.", "Strain into a cup.", "Add honey and lemon juice.", "Drink warm, 2-3 times daily."],
        duration: "3-5 days",
        warnings: "Avoid in large amounts if pregnant. Consult doctor if symptoms persist."
      },
      {
        title: "Ginger Compress for Stomach Pain",
        ingredients: ["2 inch fresh ginger", "1 liter warm water", "Clean cloth"],
        steps: ["Grate ginger and squeeze juice into warm water.", "Soak cloth in the mixture.", "Apply to stomach area for 15-20 minutes.", "Repeat 2x daily."],
        duration: "1-3 days",
        warnings: "Do not apply to broken skin."
      }
    ],
    identification: {
      leaves: "Long, narrow lance-shaped leaves, bright green",
      stem: "Upright green stem, can reach 1 meter",
      flower: "Yellow-green flowers with purple tips",
      root: "Knobby, pale yellow inside, aromatic when cut",
      habitat: "Tropical and subtropical regions, moist soil"
    },
    origin: "Southeast Asia",
    tags: ["anti-inflammatory", "digestive", "warming"]
  },
  {
    id: 2,
    name: "Turmeric",
    scientific: "Curcuma longa",
    category: "root",
    image: "🌿",
    color: "#e8a020",
    description: "The golden spice of life, revered in Ayurvedic medicine for over 4,000 years for its powerful anti-inflammatory and healing properties.",
    parts: ["Root", "Leaves"],
    ailments: ["inflammation", "liver", "heart", "wounds", "arthritis", "skin"],
    remedies: [
      {
        title: "Golden Milk for Liver & Heart Health",
        ingredients: ["1 tsp turmeric powder", "1 cup warm milk (or plant milk)", "1/4 tsp black pepper", "1 tsp honey", "Pinch of cinnamon"],
        steps: ["Heat milk until warm (not boiling).", "Add turmeric and black pepper.", "Stir well for 2 minutes.", "Add honey and cinnamon.", "Drink before bed daily."],
        duration: "Daily for 4-6 weeks",
        warnings: "Black pepper is essential — it increases turmeric absorption by 2000%. Do not use with blood thinners without consulting doctor."
      },
      {
        title: "Turmeric Paste for Wounds",
        ingredients: ["2 tbsp turmeric powder", "Coconut oil", "Clean bandage"],
        steps: ["Mix turmeric with enough coconut oil to form a paste.", "Clean the wound gently.", "Apply paste to wound.", "Cover with bandage.", "Change twice daily."],
        duration: "Until healed",
        warnings: "Will stain skin yellow temporarily. Not for deep wounds."
      }
    ],
    identification: {
      leaves: "Large, oblong, bright green with prominent midrib",
      stem: "Short pseudostem formed by leaf sheaths",
      flower: "Pale yellow flowers in dense spikes",
      root: "Bright orange-yellow inside, earthy aroma",
      habitat: "Tropical regions, well-drained moist soil"
    },
    origin: "South Asia",
    tags: ["anti-inflammatory", "liver-support", "antioxidant"]
  },
  {
    id: 3,
    name: "Garlic",
    scientific: "Allium sativum",
    category: "bulb",
    image: "🧄",
    color: "#c8b89a",
    description: "Nature's antibiotic — used across every culture on earth for fighting infections, supporting the heart, and boosting immunity.",
    parts: ["Bulb", "Leaves", "Flowers"],
    ailments: ["cold", "cough", "heart", "blood pressure", "infection", "immunity"],
    remedies: [
      {
        title: "Garlic Honey Syrup for Cold",
        ingredients: ["5-6 garlic cloves", "3 tbsp raw honey", "Small jar"],
        steps: ["Peel and roughly crush garlic cloves.", "Place in jar and cover with honey.", "Let sit for at least 24 hours.", "Take 1 teaspoon 3x daily.", "Can be stored in fridge for 1 week."],
        duration: "5-7 days",
        warnings: "May cause stomach upset on empty stomach. Avoid before surgery."
      },
      {
        title: "Garlic Tea for Blood Pressure",
        ingredients: ["3 garlic cloves", "2 cups water", "Lemon juice", "Honey to taste"],
        steps: ["Boil water in a pot.", "Add crushed garlic cloves.", "Simmer 5 minutes.", "Strain and add lemon juice.", "Sweeten with honey.", "Drink 1 cup in morning."],
        duration: "Daily, 6-8 weeks",
        warnings: "Consult doctor if on heart medication. Monitor blood pressure regularly."
      }
    ],
    identification: {
      leaves: "Long, flat, grass-like leaves",
      stem: "Hollow, rounded scape",
      flower: "White to pinkish globe-shaped flower heads",
      root: "White bulb with multiple cloves wrapped in papery skin",
      habitat: "Gardens worldwide, well-drained soil, full sun"
    },
    origin: "Central Asia",
    tags: ["antimicrobial", "heart-health", "immunity"]
  },
  {
    id: 4,
    name: "Aloe Vera",
    scientific: "Aloe barbadensis",
    category: "succulent",
    image: "🌵",
    color: "#7ab648",
    description: "The plant of immortality — used by ancient Egyptians for burns, wounds, and skin conditions for over 6,000 years.",
    parts: ["Leaves (gel)", "Latex"],
    ailments: ["burns", "wounds", "skin", "digestion", "sunburn", "inflammation"],
    remedies: [
      {
        title: "Fresh Aloe Gel for Burns & Wounds",
        ingredients: ["1 fresh aloe leaf", "Clean gauze or cloth"],
        steps: ["Cut a mature leaf from the outer plant.", "Wash the leaf.", "Slice open lengthwise.", "Scoop out the clear gel.", "Apply directly to burn or wound.", "Cover loosely. Repeat 2-3x daily."],
        duration: "Until healed",
        warnings: "Use only clear gel, not the yellow latex underneath skin. Do not use on deep wounds."
      },
      {
        title: "Aloe Juice for Digestion",
        ingredients: ["2 tbsp fresh aloe gel", "1 cup water or coconut water", "Lemon juice"],
        steps: ["Extract clear gel from fresh leaf.", "Blend with water.", "Add lemon juice.", "Drink in morning on empty stomach."],
        duration: "Daily for 2 weeks",
        warnings: "Use small amounts — large quantities may cause diarrhea. Avoid if pregnant."
      }
    ],
    identification: {
      leaves: "Thick, fleshy, succulent leaves with serrated edges, bluish-green",
      stem: "Very short or stemless rosette",
      flower: "Tubular yellow to orange flowers on tall spike",
      root: "Shallow, fibrous root system",
      habitat: "Dry, arid regions; grows in pots worldwide"
    },
    origin: "Arabian Peninsula",
    tags: ["wound-healing", "skin-care", "cooling"]
  },
  {
    id: 5,
    name: "Peppermint",
    scientific: "Mentha × piperita",
    category: "herb",
    image: "🌱",
    color: "#4caf7d",
    description: "A cooling, invigorating herb that calms headaches, soothes digestion, and clears congested airways.",
    parts: ["Leaves", "Stem", "Flowers"],
    ailments: ["headache", "nausea", "cold", "cough", "stomach", "fever"],
    remedies: [
      {
        title: "Peppermint Steam Inhalation for Congestion",
        ingredients: ["Handful of fresh peppermint leaves (or 5 drops oil)", "Bowl of hot water", "Towel"],
        steps: ["Boil water and pour in a bowl.", "Add peppermint leaves.", "Lean over bowl with towel over head.", "Inhale steam for 5-10 minutes.", "Repeat 2x daily."],
        duration: "Until relieved",
        warnings: "Keep eyes closed. Not for children under 2 years."
      },
      {
        title: "Peppermint Tea for Headache & Nausea",
        ingredients: ["2 tbsp fresh peppermint leaves", "2 cups boiling water", "Honey"],
        steps: ["Place leaves in cup.", "Pour boiling water over leaves.", "Steep for 5-10 minutes.", "Strain and add honey.", "Sip slowly."],
        duration: "As needed",
        warnings: "Avoid in patients with GERD/acid reflux."
      }
    ],
    identification: {
      leaves: "Oval, toothed, dark green with reddish veins, strong minty smell",
      stem: "Square stem, purplish-green",
      flower: "Small pink-lilac flowers in dense whorls",
      root: "Spreading underground runners (rhizomes)",
      habitat: "Moist soil near streams, gardens, temperate regions"
    },
    origin: "Europe & Middle East",
    tags: ["cooling", "digestive", "pain-relief"]
  },
  {
    id: 6,
    name: "Chamomile",
    scientific: "Matricaria chamomilla",
    category: "herb",
    image: "🌼",
    color: "#f0c040",
    description: "The gentle healer — calming the nervous system, reducing inflammation, and soothing the digestive system for thousands of years.",
    parts: ["Flowers", "Leaves"],
    ailments: ["anxiety", "sleep", "stomach", "skin", "inflammation", "fever"],
    remedies: [
      {
        title: "Chamomile Tea for Sleep & Anxiety",
        ingredients: ["2 tbsp dried chamomile flowers", "2 cups hot water", "1 tsp honey", "Dash of cinnamon"],
        steps: ["Place chamomile flowers in cup or strainer.", "Pour hot (not boiling) water over flowers.", "Steep for 5 minutes.", "Strain, add honey and cinnamon.", "Drink 30 minutes before bed."],
        duration: "Nightly as needed",
        warnings: "Avoid if allergic to ragweed or daisies. May interact with blood thinners."
      },
      {
        title: "Chamomile Skin Compress",
        ingredients: ["4 tbsp dried chamomile", "2 cups hot water", "Clean cloth"],
        steps: ["Steep chamomile in hot water 15 minutes.", "Let cool until warm.", "Soak cloth and wring out.", "Apply to inflamed skin.", "Leave for 20 minutes."],
        duration: "2-3x daily until improved",
        warnings: "Patch test first for sensitive skin."
      }
    ],
    identification: {
      leaves: "Finely divided, feathery, bright green",
      stem: "Branched, upright, up to 60cm tall",
      flower: "White petals with yellow center, apple-like scent",
      root: "Taproot system",
      habitat: "Fields, roadsides, gardens, temperate Europe and Asia"
    },
    origin: "Europe & Western Asia",
    tags: ["calming", "anti-inflammatory", "digestive"]
  },
  {
    id: 7,
    name: "Plantain",
    scientific: "Plantago major",
    category: "herb",
    image: "🍃",
    color: "#5d8a45",
    description: "The traveler's friend — grows everywhere and is one of the most useful emergency plants for wounds, insect bites, and respiratory issues.",
    parts: ["Leaves", "Seeds"],
    ailments: ["wounds", "bites", "cough", "bronchitis", "infection", "bleeding"],
    remedies: [
      {
        title: "Plantain Leaf Poultice for Wounds & Bites",
        ingredients: ["Several fresh plantain leaves", "Clean cloth or gauze"],
        steps: ["Find fresh plantain leaves (common roadside plant).", "Wash leaves thoroughly.", "Chew or crush leaves to release juice.", "Apply directly to wound or bite.", "Wrap with cloth.", "Change every few hours."],
        duration: "Until healed",
        warnings: "Emergency use only. Clean wound first if possible."
      },
      {
        title: "Plantain Cough Syrup",
        ingredients: ["1 cup fresh plantain leaves", "1 cup water", "3 tbsp honey", "1 tsp lemon juice"],
        steps: ["Boil leaves in water for 10 minutes.", "Strain and let cool.", "Add honey and lemon.", "Store in clean jar.", "Take 1 tablespoon 3-4x daily."],
        duration: "5-7 days",
        warnings: "Refrigerate and use within 3 days."
      }
    ],
    identification: {
      leaves: "Oval to elliptical, ribbed veins, green, forms ground rosette",
      stem: "Leafless flower stalk rising from center",
      flower: "Tiny greenish-white flowers on a tall spike",
      root: "Short taproot with fibrous side roots",
      habitat: "Everywhere — lawns, roadsides, fields, gardens worldwide"
    },
    origin: "Europe & Central Asia (now worldwide)",
    tags: ["wound-healing", "emergency", "respiratory"]
  },
  {
    id: 8,
    name: "Elderberry",
    scientific: "Sambucus nigra",
    category: "shrub",
    image: "🫐",
    color: "#6a3d7a",
    description: "The medicine chest of country people — elderberry has been used for centuries to fight flu, boost immunity, and ease respiratory illness.",
    parts: ["Berries", "Flowers", "Bark"],
    ailments: ["cold", "flu", "immunity", "fever", "cough", "sinus"],
    remedies: [
      {
        title: "Elderberry Syrup for Flu & Immunity",
        ingredients: ["1 cup dried elderberries", "3 cups water", "1 tsp cinnamon", "1/2 tsp cloves", "1 cup raw honey"],
        steps: ["Combine elderberries, water, cinnamon, cloves in pot.", "Bring to boil then simmer 45 minutes until reduced by half.", "Mash berries and strain through cloth.", "Let cool to room temperature.", "Stir in honey.", "Store in fridge up to 2 months.", "Take 1 tbsp daily for prevention, 1 tbsp every 2 hours when sick."],
        duration: "Daily prevention or during illness",
        warnings: "Never eat raw elderberries. Do not give honey to infants under 1 year."
      }
    ],
    identification: {
      leaves: "Pinnate leaves, 5-9 oval leaflets, serrated edges",
      stem: "Woody stems with light brown bark",
      flower: "Clusters of tiny, fragrant cream-white flowers (umbels)",
      root: "Deep root system",
      habitat: "Temperate regions, forest edges, hedgerows"
    },
    origin: "Europe & North America",
    tags: ["antiviral", "immunity", "flu"]
  },
  {
    id: 9,
    name: "Cayenne Pepper",
    scientific: "Capsicum annuum",
    category: "fruit",
    image: "🌶️",
    color: "#c0392b",
    description: "The fire medicine — capsaicin in cayenne increases circulation, stops bleeding, relieves pain, and supports heart health.",
    parts: ["Fruit", "Seeds"],
    ailments: ["heart", "circulation", "pain", "bleeding", "cold", "digestion"],
    remedies: [
      {
        title: "Cayenne Tincture for Heart & Circulation",
        ingredients: ["1 tsp cayenne pepper powder", "1 cup warm water", "Honey to taste"],
        steps: ["Mix cayenne powder in warm water.", "Add honey to taste.", "Stir well and drink quickly.", "Start with small amount and increase gradually."],
        duration: "Once daily",
        warnings: "Do NOT use as replacement for emergency cardiac care. If experiencing heart attack, call emergency services immediately. Cayenne is supportive, not curative for serious conditions."
      },
      {
        title: "Cayenne Pain Relief Paste",
        ingredients: ["1 tsp cayenne powder", "3 tbsp coconut oil or olive oil"],
        steps: ["Mix cayenne with oil to form paste.", "Apply to painful area (not near eyes or sensitive skin).", "Leave for 20-30 minutes.", "Wash off. Repeat 2-3x daily."],
        duration: "As needed",
        warnings: "Never apply to broken skin or near eyes. Wear gloves when applying. Wash hands thoroughly."
      }
    ],
    identification: {
      leaves: "Smooth, dark green, oval to lance-shaped",
      stem: "Upright, branching shrub",
      flower: "Small white flowers with purple tinge",
      root: "Fibrous root system",
      habitat: "Tropical and subtropical regions, gardens worldwide"
    },
    origin: "Central and South America",
    tags: ["circulation", "pain-relief", "heart-support"]
  },
  {
    id: 10,
    name: "Lavender",
    scientific: "Lavandula angustifolia",
    category: "herb",
    image: "💜",
    color: "#9b59b6",
    description: "The purple calmer — lavender has been used for millennia to relieve anxiety, headaches, promote sleep, and heal skin.",
    parts: ["Flowers", "Leaves", "Stems"],
    ailments: ["anxiety", "sleep", "headache", "burns", "skin", "stress"],
    remedies: [
      {
        title: "Lavender Pillow Steam for Sleep",
        ingredients: ["Handful of dried lavender flowers", "Small cloth pouch or handkerchief"],
        steps: ["Fill cloth pouch with dried lavender.", "Place near your pillow at night.", "Or steep in hot water and inhale vapor before bed.", "Breathe deeply for 5-10 minutes."],
        duration: "Nightly",
        warnings: "Some people may be sensitive to strong scents."
      },
      {
        title: "Lavender Headache Rub",
        ingredients: ["Few drops lavender essential oil", "1 tbsp carrier oil (coconut or olive)", "Or fresh lavender leaves"],
        steps: ["Mix oils together.", "Apply small amount to temples.", "Massage gently in circular motion.", "Apply to back of neck also.", "Rest in quiet room."],
        duration: "As needed",
        warnings: "Keep away from eyes. Dilute essential oil before skin contact."
      }
    ],
    identification: {
      leaves: "Narrow, grey-green, aromatic when crushed",
      stem: "Woody at base, square flower stalks",
      flower: "Dense spikes of purple-blue fragrant flowers",
      root: "Deep taproot",
      habitat: "Mediterranean regions, dry rocky soils, gardens worldwide"
    },
    origin: "Mediterranean",
    tags: ["calming", "sleep", "pain-relief"]
  },
  {
    id: 11,
    name: "Dandelion",
    scientific: "Taraxacum officinale",
    category: "herb",
    image: "🌻",
    color: "#f1c40f",
    description: "The underrated healer — considered a weed but loaded with medicine. Dandelion is powerful for liver health, digestion, and kidney function.",
    parts: ["Leaves", "Root", "Flowers"],
    ailments: ["liver", "digestion", "kidney", "inflammation", "detox", "blood sugar"],
    remedies: [
      {
        title: "Dandelion Root Tea for Liver",
        ingredients: ["2 tbsp dried dandelion root", "2 cups water", "Honey"],
        steps: ["Boil root in water for 10 minutes.", "Reduce to simmer for 5 more minutes.", "Strain into cup.", "Add honey.", "Drink 1-2 cups daily, morning and evening."],
        duration: "3-4 weeks",
        warnings: "Avoid if allergic to plants in daisy family. May interact with diuretic medications."
      },
      {
        title: "Dandelion Leaf Salad for Detox",
        ingredients: ["Young dandelion leaves (before flowering)", "Olive oil", "Lemon juice", "Salt"],
        steps: ["Pick young leaves from pesticide-free area.", "Wash thoroughly.", "Toss with olive oil and lemon juice.", "Season with salt.", "Eat 1 cup daily."],
        duration: "Daily as food",
        warnings: "Only pick from areas free of pesticides and chemicals."
      }
    ],
    identification: {
      leaves: "Deeply toothed, like a lion's teeth (dent-de-lion)", 
      stem: "Hollow flower stem with milky sap when broken",
      flower: "Bright yellow composite flowers, single per stem",
      root: "Long taproot, white inside, bitter tasting",
      habitat: "Lawns, fields, roadsides — nearly everywhere worldwide"
    },
    origin: "Eurasia (now worldwide)",
    tags: ["liver-support", "detox", "digestive"]
  },
  {
    id: 12,
    name: "Eucalyptus",
    scientific: "Eucalyptus globulus",
    category: "tree",
    image: "🌲",
    color: "#2e8b57",
    description: "The breathing tree — eucalyptus is the premier plant for respiratory health, clearing airways, fighting infection, and reducing fever.",
    parts: ["Leaves"],
    ailments: ["cough", "cold", "bronchitis", "fever", "sinus", "infection"],
    remedies: [
      {
        title: "Eucalyptus Steam for Respiratory Congestion",
        ingredients: ["Fresh or dried eucalyptus leaves", "1 liter boiling water", "Large bowl", "Towel"],
        steps: ["Boil water and pour into large bowl.", "Add a handful of eucalyptus leaves.", "Let steep 2 minutes.", "Lean over bowl, cover head with towel.", "Inhale deeply for 5-10 minutes.", "Repeat 2-3x daily."],
        duration: "Until symptoms clear",
        warnings: "Keep eyes closed. Do not use for children under 2. Keep face safe distance from hot steam."
      },
      {
        title: "Eucalyptus Fever-Reducing Sponge",
        ingredients: ["Several eucalyptus leaves", "2 cups cool water"],
        steps: ["Crush leaves and steep in cool water 20 minutes.", "Strain.", "Soak cloth in liquid.", "Sponge forehead, armpits, neck.", "Repeat as needed."],
        duration: "As needed for fever",
        warnings: "For high fever above 39.5°C / 103°F, seek medical attention."
      }
    ],
    identification: {
      leaves: "Long, sickle-shaped, blue-green, strong camphor aroma",
      stem: "Tall straight trunk, grey-white peeling bark",
      flower: "White to cream flowers without petals, bushy stamens",
      root: "Deep extensive root system",
      habitat: "Originally Australia, now planted worldwide in warm climates"
    },
    origin: "Australia",
    tags: ["respiratory", "antimicrobial", "fever-reducer"]
  }
];

const AILMENTS_INDEX = {
  "cough": [1, 5, 7, 8, 9, 12],
  "cold": [1, 3, 5, 8, 9, 12],
  "fever": [1, 5, 6, 8, 12],
  "liver": [2, 11],
  "heart": [2, 3, 9],
  "wounds": [4, 7],
  "burns": [4, 10],
  "anxiety": [6, 10],
  "sleep": [6, 10],
  "headache": [5, 10],
  "stomach": [1, 5, 6],
  "digestion": [4, 5, 6, 11],
  "inflammation": [1, 2, 6, 7, 11],
  "immunity": [3, 8],
  "pain": [5, 9, 10],
  "skin": [4, 6, 10],
  "blood pressure": [3],
  "bronchitis": [7, 12],
  "sinus": [8, 12],
  "detox": [11],
  "nausea": [1, 5]
};

const AILMENT_CATEGORIES = [
  { id: "respiratory", label: "Respiratory", icon: "🫁", ailments: ["cough", "cold", "sinus", "bronchitis", "fever"] },
  { id: "digestive", label: "Digestive", icon: "🫄", ailments: ["stomach", "digestion", "nausea", "detox"] },
  { id: "heart", label: "Heart & Blood", icon: "❤️", ailments: ["heart", "blood pressure", "circulation"] },
  { id: "pain", label: "Pain & Wounds", icon: "🩹", ailments: ["pain", "wounds", "burns", "headache", "inflammation"] },
  { id: "mental", label: "Mind & Sleep", icon: "🧠", ailments: ["anxiety", "sleep", "stress"] },
  { id: "organ", label: "Organ Support", icon: "🫀", ailments: ["liver", "kidney", "detox", "immunity"] },
  { id: "skin", label: "Skin & External", icon: "✨", ailments: ["skin", "wounds", "burns", "bites"] }
];
